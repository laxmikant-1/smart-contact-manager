/** @type {import('tailwindcss').Config} */
export default {
  content: [".SmartContactManager/src/**/*.{html,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
  darkMode: "selector",
};
