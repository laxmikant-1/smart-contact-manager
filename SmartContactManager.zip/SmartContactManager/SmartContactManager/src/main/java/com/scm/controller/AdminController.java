package com.scm.controller;

import com.scm.entities.ContactMessage;
import com.scm.repositories.ContactMessageRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class AdminController {

    private final ContactMessageRepository contactMessageRepository;

    @Autowired
    private ContactMessageRepository messageRepo;

    AdminController(ContactMessageRepository contactMessageRepository) {
        this.contactMessageRepository = contactMessageRepository;
    }

    /**
     * Handles GET requests to /admin/messages.
     * Fetches all messages from the database and sends them to the messages view.
     *
     * @param model Spring Model object to pass data to the view
     * @return the name of the Thymeleaf template to render (admin/messages.html)
     */
    @GetMapping("/admin/messages")
    public String viewMessages(Model model) {
        // Fetch all contact messages from the database
        List<ContactMessage> messages = messageRepo.findAll();

        // Add the list of messages to the model so it can be accessed in the view
        model.addAttribute("messages", messages);

        // Return the view name (Thymeleaf template) located at templates/admin/messages.html
        return "admin/messages";
    }
}
