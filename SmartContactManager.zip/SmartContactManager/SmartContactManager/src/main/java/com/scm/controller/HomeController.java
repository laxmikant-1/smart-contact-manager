package com.scm.controller;

import com.scm.entities.ContactMessage;
import com.scm.repositories.ContactMessageRepository;
import com.scm.services.EmailServices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class HomeController {

    @Autowired
    private ContactMessageRepository messageRepo;

    @Autowired
private EmailServices emailService;

@PostMapping("/send-message")
public String handleMessage(@RequestParam String name,
                            @RequestParam String email,
                            @RequestParam String message,
                            Model model) {
    ContactMessage msg = new ContactMessage(name, email, message);
    messageRepo.save(msg);

    // Send email to admin
    emailService.sendAdminNotification(name, email, message);

    model.addAttribute("success", "Your message has been sent successfully!");
    return "redirect:/"; // or redirect to contact page
}
}
