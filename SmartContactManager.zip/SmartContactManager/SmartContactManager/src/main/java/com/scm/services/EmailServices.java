package com.scm.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailServices {

    @Autowired
    private JavaMailSender mailSender;

    public void sendAdminNotification(String name, String email, String message) {
        SimpleMailMessage mail = new SimpleMailMessage();
        mail.setTo("legendroyal91@gmail.com"); // Admin email here
        mail.setSubject("New Contact Message from " + name);
        mail.setText("Name: " + name + "\nEmail: " + email + "\n\nMessage:\n" + message);
        mailSender.send(mail);
    }
}
